# Changelog

All notable changes to Site Pilot AI will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.14] - 2026-02-05

### Security
- API keys now hashed using `wp_hash_password()` instead of plain text storage
- New `spai_api_agent` role with limited capabilities (not full admin)
- New `spai_bot` service account for handling API requests
- API key shown only once after regeneration, then masked in UI
- Legacy plain-text keys auto-migrate to hashed on first API request
- Freemius SDK private method calls wrapped in try-catch

### Fixed
- Corrected `is_premium` flag to `false` for free version
- Improved backward compatibility for existing installations

## [1.0.13] - 2026-02-05

### Changed
- Switched plugin updates from GitHub to Freemius
- Removed custom GitHub updater class
- Removed `uninstall.php` (using Freemius `after_uninstall` hook instead)

### Added
- Transient and cron cleanup in Freemius uninstall hook

### Removed
- `class-spai-updater.php`
- GitHub token settings from admin

## [1.0.12] - 2026-02-04

### Changed
- Updated Freemius SDK integration with correct configuration
- Renamed `spai_fs()` to `spa_fs()` per Freemius conventions
- Added multisite network support (`WP_FS__PRODUCT_23824_MULTISITE`)

### Added
- 14-day trial configuration with payment requirement
- Custom connect message for opt-in screen

## [1.0.11] - 2026-02-04

### Added
- Freemius SDK integration for licensing and updates
- License management abstraction layer (`Spai_License` class)
- Upgrade banner in admin dashboard
- Support for Pro, Agency plans via Freemius

### Changed
- License checking now uses unified interface (supports Freemius or custom backend)

## [1.0.0] - 2024-01-01

### Added
- Initial release
- REST API with 14 endpoints
- Posts CRUD operations (create, read, update, delete)
- Pages CRUD operations
- Media upload (file and URL)
- Draft management (list and bulk delete)
- Basic Elementor support (get/set page data, create Elementor page)
- API key authentication
- Activity logging with configurable retention
- Admin settings page
- Plugin detection for Elementor, SEO plugins, form plugins, WooCommerce
- WordPress.org compliant readme.txt
- Internationalization support
- Clean uninstall

### Security
- CSRF protection with nonces
- Capability checks on all admin actions
- Input sanitization using WordPress functions
- Output escaping
- Secure API key generation
- Rate limiting ready architecture

## [Unreleased]

### Planned
- Pro add-on with full Elementor integration
- SEO module (Yoast, RankMath, AIOSEO, SEOPress)
- Forms module (CF7, WPForms, Gravity Forms, Ninja Forms)
- Landing page builder
- Template management
- Agency tier with multi-site support
