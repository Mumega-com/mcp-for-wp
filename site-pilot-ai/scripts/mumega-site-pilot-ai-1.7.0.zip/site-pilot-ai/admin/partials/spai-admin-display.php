<?php
/**
 * Admin page template
 *
 * @package SitePilotAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$stored_key_hash = get_option( 'spai_api_key', '' );
$admin           = new Spai_Admin();
$capabilities    = $admin->get_capabilities_display();
$is_pro          = true;
$is_first        = get_option( 'spai_first_activation', false );
$rest_base       = rest_url( 'site-pilot-ai/v1/' );
$mcp_url         = rest_url( 'site-pilot-ai/v1/mcp' );
$site_name       = get_bloginfo( 'name' );
$site_slug       = sanitize_title( $site_name );
// Non-Latin site names (Persian, Arabic, CJK) produce URL-encoded slugs — fall back to hostname.
if ( empty( $site_slug ) || false !== strpos( $site_slug, '%' ) ) {
	$site_slug = preg_replace( '/^www\./', '', wp_parse_url( home_url(), PHP_URL_HOST ) );
	$site_slug = str_replace( '.', '-', $site_slug );
}

// Current tab — admin page, read-only navigation parameter.
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$current_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'setup';

// Determine key display
if ( isset( $new_key ) && $new_key ) {
	$display_key = $new_key;
	$is_hidden   = false;
} elseif ( ! empty( $stored_key_hash ) ) {
	$display_key = 'spai_******************** (Hidden)';
	$is_hidden   = true;
} else {
	$display_key = '';
	$is_hidden   = false;
}
?>

<div class="wrap spai-admin">
	<h1 class="spai-header">
		<span class="spai-logo">
			<span class="dashicons dashicons-airplane"></span>
		</span>
		<?php esc_html_e( 'Mumega Site Pilot AI', 'site-pilot-ai' ); ?>
		<span class="spai-version">v<?php echo esc_html( SPAI_VERSION ); ?></span>
	</h1>

	<?php if ( $is_first && isset( $new_key ) && $new_key ) : ?>
	<!-- First-time welcome banner -->
	<div class="spai-welcome-banner" id="spai-welcome">
		<div class="spai-welcome-icon">
			<span class="dashicons dashicons-yes-alt"></span>
		</div>
		<div class="spai-welcome-content">
			<h2><?php esc_html_e( 'Site Pilot AI is ready!', 'site-pilot-ai' ); ?></h2>
			<p><?php esc_html_e( 'Your API key has been generated. Copy it now and use it to connect Claude Desktop, Claude Code, or ChatGPT to your WordPress site.', 'site-pilot-ai' ); ?></p>
			<div class="spai-api-key-wrapper spai-api-key-wrapper--highlight">
				<input
					type="text"
					id="spai-welcome-key"
					class="spai-api-key-input"
					value="<?php echo esc_attr( $new_key ); ?>"
					readonly
				/>
				<button type="button" class="button button-primary spai-copy-btn" data-copy="<?php echo esc_attr( $new_key ); ?>">
					<span class="dashicons dashicons-clipboard"></span>
					<?php esc_html_e( 'Copy Key', 'site-pilot-ai' ); ?>
				</button>
			</div>
			<p class="spai-welcome-warning">
				<strong><?php esc_html_e( 'Save this key now!', 'site-pilot-ai' ); ?></strong>
				<?php esc_html_e( 'It will not be shown again after you leave this page. You can always regenerate a new key.', 'site-pilot-ai' ); ?>
			</p>
			<button type="button" class="button spai-dismiss-welcome" id="spai-dismiss-welcome">
				<?php esc_html_e( 'Got it, I\'ve saved my key', 'site-pilot-ai' ); ?>
			</button>
		</div>
	</div>
	<?php endif; ?>

	<div class="spai-license-banner spai-license-active">
		<div class="spai-license-content">
			<span class="dashicons dashicons-yes-alt"></span>
			<strong><?php esc_html_e( 'All features included', 'site-pilot-ai' ); ?></strong>
			&mdash;
			<a href="https://mumega.com/" target="_blank"><?php esc_html_e( 'Powered by Mumega', 'site-pilot-ai' ); ?></a>
		</div>
	</div>

	<!-- Tab Navigation -->
	<nav class="nav-tab-wrapper spai-tabs">
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=site-pilot-ai&tab=setup' ) ); ?>"
		   class="nav-tab <?php echo 'setup' === $current_tab ? 'nav-tab-active' : ''; ?>">
			<span class="dashicons dashicons-admin-tools"></span>
			<?php esc_html_e( 'Setup', 'site-pilot-ai' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=site-pilot-ai&tab=connect' ) ); ?>"
		   class="nav-tab <?php echo 'connect' === $current_tab ? 'nav-tab-active' : ''; ?>">
			<span class="dashicons dashicons-cloud"></span>
			<?php esc_html_e( 'Connect AI', 'site-pilot-ai' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=site-pilot-ai&tab=settings' ) ); ?>"
		   class="nav-tab <?php echo 'settings' === $current_tab ? 'nav-tab-active' : ''; ?>">
			<span class="dashicons dashicons-admin-generic"></span>
			<?php esc_html_e( 'Settings', 'site-pilot-ai' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=site-pilot-ai&tab=advanced' ) ); ?>"
		   class="nav-tab <?php echo 'advanced' === $current_tab ? 'nav-tab-active' : ''; ?>">
			<span class="dashicons dashicons-editor-code"></span>
			<?php esc_html_e( 'Advanced', 'site-pilot-ai' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=site-pilot-ai&tab=changelog' ) ); ?>"
		   class="nav-tab <?php echo 'changelog' === $current_tab ? 'nav-tab-active' : ''; ?>">
			<span class="dashicons dashicons-list-view"></span>
			<?php esc_html_e( 'Changelog', 'site-pilot-ai' ); ?>
		</a>
	</nav>

	<!-- ======================== SETUP TAB ======================== -->
	<?php if ( 'setup' === $current_tab ) : ?>

	<div class="spai-tab-content">
		<!-- Recent Activity Card -->
		<div class="spai-card">
			<h2><?php esc_html_e( 'Recent Activity', 'site-pilot-ai' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Latest API activity captured by Site Pilot AI. Use Activity Log for full history and details.', 'site-pilot-ai' ); ?>
			</p>

			<?php
			$recent = $admin->get_recent_activity_rows( 10 );
			$activity_url = admin_url( 'admin.php?page=' . Spai_Admin::ACTIVITY_LOG_PAGE_SLUG );
			?>

			<?php if ( empty( $recent ) ) : ?>
				<p><em><?php esc_html_e( 'No activity yet.', 'site-pilot-ai' ); ?></em></p>
			<?php else : ?>
				<table class="widefat striped">
					<thead>
						<tr>
							<th style="width:160px;"><?php esc_html_e( 'When', 'site-pilot-ai' ); ?></th>
							<th style="width:140px;"><?php esc_html_e( 'Action', 'site-pilot-ai' ); ?></th>
							<th><?php esc_html_e( 'Endpoint', 'site-pilot-ai' ); ?></th>
							<th style="width:70px;"><?php esc_html_e( 'Method', 'site-pilot-ai' ); ?></th>
							<th style="width:70px;"><?php esc_html_e( 'Status', 'site-pilot-ai' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $recent as $row ) : ?>
						<tr>
							<td><?php echo esc_html( (string) $row['created_at'] ); ?></td>
							<td><?php echo esc_html( (string) $row['action'] ); ?></td>
							<td><code><?php echo esc_html( (string) $row['endpoint'] ); ?></code></td>
							<td><?php echo esc_html( (string) $row['method'] ); ?></td>
							<td><?php echo esc_html( (string) $row['status_code'] ); ?></td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<p style="margin-top:10px;">
					<a class="button" href="<?php echo esc_url( $activity_url ); ?>"><?php esc_html_e( 'Open Activity Log', 'site-pilot-ai' ); ?></a>
				</p>
			<?php endif; ?>
		</div>

		<!-- API Key Card -->
		<div class="spai-card">
			<h2><?php esc_html_e( 'API Key', 'site-pilot-ai' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'This key authenticates AI assistants (Claude, ChatGPT) when they connect to your site.', 'site-pilot-ai' ); ?>
			</p>

			<div class="spai-api-key-wrapper">
				<input
					type="text"
					id="spai-api-key"
					class="spai-api-key-input"
					value="<?php echo esc_attr( $display_key ); ?>"
					readonly
				/>
				<?php if ( ! $is_hidden ) : ?>
				<button type="button" class="button spai-copy-btn" data-copy="<?php echo esc_attr( $display_key ); ?>">
					<span class="dashicons dashicons-clipboard"></span>
					<?php esc_html_e( 'Copy', 'site-pilot-ai' ); ?>
				</button>
				<?php endif; ?>
			</div>

			<?php if ( $is_hidden ) : ?>
			<p class="description">
				<?php esc_html_e( 'Your API key is stored securely (hashed). To see it, regenerate a new one below.', 'site-pilot-ai' ); ?>
			</p>
			<?php endif; ?>

			<form method="post" class="spai-regenerate-form">
				<?php wp_nonce_field( 'spai_regenerate_key', 'spai_nonce' ); ?>
				<button type="submit" name="spai_regenerate_key" class="button spai-regenerate-btn">
					<span class="dashicons dashicons-update"></span>
					<?php esc_html_e( 'Regenerate Key', 'site-pilot-ai' ); ?>
				</button>
				<span class="description">
					<?php esc_html_e( 'The old key will stop working immediately.', 'site-pilot-ai' ); ?>
				</span>
			</form>

			<h3><?php esc_html_e( 'API Keys', 'site-pilot-ai' ); ?></h3>
			<p class="description">
				<?php esc_html_e( 'Create role-based keys to control which tools AI assistants can access. Each role limits the MCP tools visible to the AI.', 'site-pilot-ai' ); ?>
			</p>

			<?php if ( ! empty( $new_scoped_key['key'] ) ) : ?>
			<div class="spai-api-key-wrapper spai-api-key-wrapper--highlight">
				<input
					type="text"
					class="spai-api-key-input"
					value="<?php echo esc_attr( $new_scoped_key['key'] ); ?>"
					readonly
				/>
				<button type="button" class="button button-primary spai-copy-btn" data-copy="<?php echo esc_attr( $new_scoped_key['key'] ); ?>">
					<span class="dashicons dashicons-clipboard"></span>
					<?php esc_html_e( 'Copy Key', 'site-pilot-ai' ); ?>
				</button>
			</div>
			<?php endif; ?>

			<?php
			$role_definitions = Spai_Admin::get_role_definitions();
			$all_cat_labels   = Spai_Admin::get_all_tool_category_labels();
			?>

			<form method="post" class="spai-regenerate-form">
				<?php wp_nonce_field( 'spai_manage_scoped_keys', 'spai_scoped_keys_nonce' ); ?>
				<p>
					<label for="spai_scoped_key_label"><strong><?php esc_html_e( 'Label', 'site-pilot-ai' ); ?></strong></label><br />
					<input type="text" id="spai_scoped_key_label" name="spai_scoped_key_label" class="regular-text" placeholder="<?php esc_attr_e( 'Example: Content Writer Bot', 'site-pilot-ai' ); ?>" />
				</p>
				<p>
					<label for="spai_scoped_key_role"><strong><?php esc_html_e( 'Role', 'site-pilot-ai' ); ?></strong></label><br />
					<select id="spai_scoped_key_role" name="spai_scoped_key_role" style="min-width:200px;">
						<?php foreach ( $role_definitions as $role_slug => $role_def ) : ?>
						<option value="<?php echo esc_attr( $role_slug ); ?>"
							data-categories="<?php echo esc_attr( wp_json_encode( $role_def['categories'] ) ); ?>">
							<?php echo esc_html( $role_def['label'] ); ?> &mdash; <?php echo esc_html( $role_def['description'] ); ?>
						</option>
						<?php endforeach; ?>
					</select>
				</p>
				<div id="spai-custom-categories" style="display:none;margin-bottom:12px;">
					<strong><?php esc_html_e( 'Tool Categories', 'site-pilot-ai' ); ?></strong><br />
					<p class="description" style="margin-bottom:6px;">
						<?php esc_html_e( 'Select which tool categories this key can access.', 'site-pilot-ai' ); ?>
					</p>
					<?php foreach ( $all_cat_labels as $cat_slug => $cat_label ) : ?>
					<label style="display:inline-block;min-width:120px;margin:2px 0;">
						<input type="checkbox" name="spai_scoped_key_categories[]" value="<?php echo esc_attr( $cat_slug ); ?>" class="spai-category-checkbox" />
						<?php echo esc_html( $cat_label ); ?>
					</label>
					<?php endforeach; ?>
				</div>
				<div id="spai-role-preview" style="margin-bottom:12px;padding:8px 12px;background:#f0f0f1;border-radius:4px;display:none;">
					<strong><?php esc_html_e( 'Access:', 'site-pilot-ai' ); ?></strong>
					<span id="spai-role-preview-categories"></span>
				</div>
				<p>
					<strong><?php esc_html_e( 'Scopes', 'site-pilot-ai' ); ?></strong><br />
					<label><input type="checkbox" name="spai_scoped_key_scopes[]" value="read" checked /> <?php esc_html_e( 'Read', 'site-pilot-ai' ); ?></label>
					<label style="margin-left:12px;"><input type="checkbox" name="spai_scoped_key_scopes[]" value="write" /> <?php esc_html_e( 'Write', 'site-pilot-ai' ); ?></label>
					<label style="margin-left:12px;"><input type="checkbox" name="spai_scoped_key_scopes[]" value="admin" /> <?php esc_html_e( 'Admin', 'site-pilot-ai' ); ?></label>
				</p>
				<button type="submit" name="spai_create_scoped_key" class="button button-primary">
					<?php esc_html_e( 'Create API Key', 'site-pilot-ai' ); ?>
				</button>
			</form>

			<script>
			(function() {
				var roleSelect = document.getElementById('spai_scoped_key_role');
				var customDiv  = document.getElementById('spai-custom-categories');
				var previewDiv = document.getElementById('spai-role-preview');
				var previewCat = document.getElementById('spai-role-preview-categories');
				var checkboxes = document.querySelectorAll('.spai-category-checkbox');
				var catLabels  = <?php echo wp_json_encode( $all_cat_labels ); ?>;

				function updateRoleUI() {
					var sel  = roleSelect.options[roleSelect.selectedIndex];
					var role = sel.value;
					var cats = JSON.parse(sel.getAttribute('data-categories') || '[]');

					if (role === 'custom') {
						customDiv.style.display = 'block';
						previewDiv.style.display = 'none';
					} else if (role === 'admin') {
						customDiv.style.display = 'none';
						previewDiv.style.display = 'block';
						previewCat.textContent = '<?php echo esc_js( __( 'All categories (unrestricted)', 'site-pilot-ai' ) ); ?>';
					} else {
						customDiv.style.display = 'none';
						previewDiv.style.display = 'block';
						var labels = cats.map(function(c) { return catLabels[c] || c; });
						previewCat.textContent = labels.join(', ');
					}

					// Auto-check matching categories for preset roles.
					if (role !== 'custom') {
						checkboxes.forEach(function(cb) {
							cb.checked = cats.indexOf(cb.value) !== -1;
						});
					}
				}

				roleSelect.addEventListener('change', updateRoleUI);
				updateRoleUI();
			})();
			</script>

			<?php
			// Compute role badge colors.
			$role_colors = array(
				'admin'    => '#d63638',
				'author'   => '#2271b1',
				'designer' => '#8c5fc7',
				'editor'   => '#00a32a',
				'custom'   => '#996800',
			);
			?>

			<?php if ( ! empty( $scoped_keys ) ) : ?>
			<table class="widefat striped" style="margin-top:12px;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Label', 'site-pilot-ai' ); ?></th>
						<th><?php esc_html_e( 'Role', 'site-pilot-ai' ); ?></th>
						<th><?php esc_html_e( 'Categories', 'site-pilot-ai' ); ?></th>
						<th><?php esc_html_e( 'Created', 'site-pilot-ai' ); ?></th>
						<th><?php esc_html_e( 'Last Used', 'site-pilot-ai' ); ?></th>
						<th><?php esc_html_e( 'Status', 'site-pilot-ai' ); ?></th>
						<th><?php esc_html_e( 'Action', 'site-pilot-ai' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $scoped_keys as $key ) :
						$key_role  = isset( $key['role'] ) ? $key['role'] : 'admin';
						$role_def  = isset( $role_definitions[ $key_role ] ) ? $role_definitions[ $key_role ] : $role_definitions['admin'];
						$badge_bg  = isset( $role_colors[ $key_role ] ) ? $role_colors[ $key_role ] : '#50575e';

						// Resolve display categories.
						$display_cats = array();
						if ( 'admin' === $key_role ) {
							$display_cats = array( __( 'All', 'site-pilot-ai' ) );
						} elseif ( 'custom' === $key_role && ! empty( $key['tool_categories'] ) ) {
							foreach ( $key['tool_categories'] as $cat ) {
								$display_cats[] = isset( $all_cat_labels[ $cat ] ) ? $all_cat_labels[ $cat ] : $cat;
							}
						} elseif ( ! empty( $role_def['categories'] ) ) {
							foreach ( $role_def['categories'] as $cat ) {
								$display_cats[] = isset( $all_cat_labels[ $cat ] ) ? $all_cat_labels[ $cat ] : $cat;
							}
						}
					?>
					<tr<?php echo ! empty( $key['revoked_at'] ) ? ' style="opacity:0.5;"' : ''; ?>>
						<td><strong><?php echo esc_html( $key['label'] ); ?></strong></td>
						<td>
							<span style="display:inline-block;background:<?php echo esc_attr( $badge_bg ); ?>;color:#fff;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">
								<?php echo esc_html( $role_def['label'] ); ?>
							</span>
						</td>
						<td><?php echo esc_html( implode( ', ', $display_cats ) ); ?></td>
						<td><?php echo ! empty( $key['created_at'] ) ? esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $key['created_at'] ) ) ) : '&mdash;'; ?></td>
						<td><?php echo ! empty( $key['last_used_at'] ) ? esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $key['last_used_at'] ) ) ) : '&mdash;'; ?></td>
						<td>
							<?php if ( ! empty( $key['revoked_at'] ) ) : ?>
								<span class="spai-status spai-status-inactive"><?php esc_html_e( 'Revoked', 'site-pilot-ai' ); ?></span>
							<?php else : ?>
								<span class="spai-status spai-status-active"><?php esc_html_e( 'Active', 'site-pilot-ai' ); ?></span>
							<?php endif; ?>
						</td>
						<td>
							<?php if ( empty( $key['revoked_at'] ) ) : ?>
							<form method="post" style="display:inline;">
								<?php wp_nonce_field( 'spai_manage_scoped_keys', 'spai_scoped_keys_nonce' ); ?>
								<input type="hidden" name="spai_scoped_key_id" value="<?php echo esc_attr( $key['id'] ); ?>" />
								<button type="submit" name="spai_revoke_scoped_key" class="button button-link-delete" onclick="return confirm('<?php echo esc_js( __( 'Revoke this key?', 'site-pilot-ai' ) ); ?>');">
									<?php esc_html_e( 'Revoke', 'site-pilot-ai' ); ?>
								</button>
							</form>
							<?php else : ?>
								&mdash;
							<?php endif; ?>
						</td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>
		</div>

		<!-- Test Connection Card -->
		<div class="spai-card">
			<h2><?php esc_html_e( 'Connection Status', 'site-pilot-ai' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Verify that your REST API is working correctly.', 'site-pilot-ai' ); ?>
			</p>

			<div class="spai-test-connection">
				<button type="button" class="button button-primary" id="spai-test-btn">
					<span class="dashicons dashicons-yes-alt"></span>
					<?php esc_html_e( 'Test Connection', 'site-pilot-ai' ); ?>
				</button>
				<div class="spai-test-result" id="spai-test-result" style="display:none;">
					<div class="spai-test-success" style="display:none;">
						<span class="dashicons dashicons-yes"></span>
						<span class="spai-test-message"></span>
					</div>
					<div class="spai-test-error" style="display:none;">
						<span class="dashicons dashicons-no"></span>
						<span class="spai-test-message"></span>
					</div>
					<div class="spai-test-details" style="display:none;"></div>
				</div>
			</div>
		</div>

		<!-- Detected Capabilities Card -->
		<div class="spai-card">
			<h2><?php esc_html_e( 'Detected Capabilities', 'site-pilot-ai' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Plugins detected on your site that Site Pilot AI can work with.', 'site-pilot-ai' ); ?>
			</p>
			<table class="widefat spai-capabilities-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Feature', 'site-pilot-ai' ); ?></th>
						<th><?php esc_html_e( 'Status', 'site-pilot-ai' ); ?></th>
						<th><?php esc_html_e( 'Details', 'site-pilot-ai' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $capabilities as $key => $cap ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $cap['label'] ); ?></strong></td>
						<td>
							<?php if ( $cap['active'] ) : ?>
								<span class="spai-status spai-status-active"><?php esc_html_e( 'Active', 'site-pilot-ai' ); ?></span>
							<?php else : ?>
								<span class="spai-status spai-status-inactive"><?php esc_html_e( 'Not Detected', 'site-pilot-ai' ); ?></span>
							<?php endif; ?>
						</td>
						<td>
							<?php
							if ( isset( $cap['pro'] ) && $cap['pro'] ) {
								echo '<span class="spai-badge spai-badge-pro">Pro</span> ';
							}
							if ( isset( $cap['name'] ) && $cap['name'] ) {
								echo esc_html( $cap['name'] );
							}
							if ( isset( $cap['names'] ) && ! empty( $cap['names'] ) ) {
								echo esc_html( implode( ', ', $cap['names'] ) );
							}
							?>
						</td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>

	<!-- ======================== CONNECT AI TAB ======================== -->
	<?php elseif ( 'connect' === $current_tab ) : ?>

	<div class="spai-tab-content">
		<!-- Claude Desktop — Custom Connector (Recommended) -->
		<div class="spai-card">
			<h2>
				<span class="dashicons dashicons-cloud"></span>
				<?php esc_html_e( 'Claude Desktop — Custom Connector', 'site-pilot-ai' ); ?>
				<span class="spai-badge" style="background:#28a745;color:#fff;margin-left:8px;"><?php esc_html_e( 'Recommended', 'site-pilot-ai' ); ?></span>
			</h2>
			<p class="description">
				<?php esc_html_e( 'The fastest way to connect. No config files, no npm — just paste a URL.', 'site-pilot-ai' ); ?>
			</p>

			<div class="spai-setup-steps">
				<div class="spai-step">
					<span class="spai-step-number">1</span>
					<div class="spai-step-content">
						<h3><?php esc_html_e( 'Open Connectors', 'site-pilot-ai' ); ?></h3>
						<p><?php esc_html_e( 'In Claude Desktop, go to Settings → Connectors → Add custom connector', 'site-pilot-ai' ); ?></p>
					</div>
				</div>

				<div class="spai-step">
					<span class="spai-step-number">2</span>
					<div class="spai-step-content">
						<h3><?php esc_html_e( 'Fill in the fields', 'site-pilot-ai' ); ?></h3>
						<table class="spai-connector-fields">
							<tr>
								<td><strong><?php esc_html_e( 'Name', 'site-pilot-ai' ); ?></strong></td>
								<td>
									<div class="spai-code-wrapper spai-code-inline">
										<code id="spai-connector-name">sitepilotai-<?php echo esc_html( $site_slug ); ?></code>
										<button type="button" class="button spai-copy-code-btn spai-copy-code-btn--inline" data-target="spai-connector-name">
											<span class="dashicons dashicons-clipboard"></span>
										</button>
									</div>
								</td>
							</tr>
							<tr>
								<td><strong><?php esc_html_e( 'Remote MCP server URL', 'site-pilot-ai' ); ?></strong></td>
								<td>
									<div class="spai-code-wrapper spai-code-inline">
										<code id="spai-connector-url"><?php echo esc_url( add_query_arg( 'api_key', ( $is_hidden ? 'YOUR_API_KEY' : $display_key ), $mcp_url ) ); ?></code>
										<button type="button" class="button spai-copy-code-btn spai-copy-code-btn--inline" data-target="spai-connector-url">
											<span class="dashicons dashicons-clipboard"></span>
										</button>
									</div>
								</td>
							</tr>
							<tr>
								<td><strong><?php esc_html_e( 'OAuth fields', 'site-pilot-ai' ); ?></strong></td>
								<td><em><?php esc_html_e( 'Leave empty', 'site-pilot-ai' ); ?></em></td>
							</tr>
						</table>
						<?php if ( $is_hidden ) : ?>
						<p class="description" style="margin-top:10px;">
							<?php esc_html_e( 'Replace YOUR_API_KEY with your actual API key from the Setup tab.', 'site-pilot-ai' ); ?>
						</p>
						<?php endif; ?>
					</div>
				</div>

				<div class="spai-step">
					<span class="spai-step-number">3</span>
					<div class="spai-step-content">
						<h3><?php esc_html_e( 'Done!', 'site-pilot-ai' ); ?></h3>
						<p><?php esc_html_e( 'Claude Desktop will connect immediately. You should see your WordPress tools in the conversation.', 'site-pilot-ai' ); ?></p>
					</div>
				</div>
			</div>
		</div>

		<!-- Claude Desktop — JSON Config -->
		<div class="spai-card">
			<h2>
				<span class="dashicons dashicons-cloud"></span>
				<?php esc_html_e( 'Claude Desktop — JSON Config', 'site-pilot-ai' ); ?>
			</h2>
			<p class="description">
				<?php esc_html_e( 'Alternative method using the config file. Uses header-based auth (more secure for shared machines).', 'site-pilot-ai' ); ?>
			</p>

			<div class="spai-setup-steps">
				<div class="spai-step">
					<span class="spai-step-number">1</span>
					<div class="spai-step-content">
						<h3><?php esc_html_e( 'Open Claude Desktop Settings', 'site-pilot-ai' ); ?></h3>
						<p><?php esc_html_e( 'Go to Claude Desktop → Settings → Developer → Edit Config', 'site-pilot-ai' ); ?></p>
					</div>
				</div>

				<div class="spai-step">
					<span class="spai-step-number">2</span>
					<div class="spai-step-content">
						<h3><?php esc_html_e( 'Add this configuration', 'site-pilot-ai' ); ?></h3>
						<p><?php esc_html_e( 'Paste this into your claude_desktop_config.json file:', 'site-pilot-ai' ); ?></p>
						<div class="spai-code-wrapper">
							<pre class="spai-code-block" id="spai-claude-config">{
  "mcpServers": {
    "sitepilotai-<?php echo esc_html( $site_slug ); ?>": {
      "url": "<?php echo esc_url( $mcp_url ); ?>",
      "headers": {
        "X-API-Key": "<?php echo $is_hidden ? 'YOUR_API_KEY_HERE' : esc_attr( $display_key ); ?>"
      }
    }
  }
}</pre>
							<button type="button" class="button spai-copy-code-btn" data-target="spai-claude-config">
								<span class="dashicons dashicons-clipboard"></span>
								<?php esc_html_e( 'Copy', 'site-pilot-ai' ); ?>
							</button>
						</div>
					</div>
				</div>

				<div class="spai-step">
					<span class="spai-step-number">3</span>
					<div class="spai-step-content">
						<h3><?php esc_html_e( 'Restart Claude Desktop', 'site-pilot-ai' ); ?></h3>
						<p><?php esc_html_e( 'After saving the config, restart Claude Desktop. You should see the WordPress tools appear.', 'site-pilot-ai' ); ?></p>
					</div>
				</div>
			</div>
		</div>

		<!-- Claude Code (CLI) -->
		<div class="spai-card">
			<h2>
				<span class="dashicons dashicons-terminal"></span>
				<?php esc_html_e( 'Claude Code (CLI)', 'site-pilot-ai' ); ?>
			</h2>
			<p class="description">
				<?php esc_html_e( 'For developers using Claude Code in the terminal. Connects directly via Streamable HTTP — no proxy needed.', 'site-pilot-ai' ); ?>
			</p>

			<div class="spai-setup-steps">
				<div class="spai-step">
					<span class="spai-step-number">1</span>
					<div class="spai-step-content">
						<h3><?php esc_html_e( 'Add to your project settings', 'site-pilot-ai' ); ?></h3>
						<p><?php esc_html_e( 'Add to .mcp.json in your project root or ~/.claude.json for global access:', 'site-pilot-ai' ); ?></p>
						<div class="spai-code-wrapper">
							<pre class="spai-code-block" id="spai-claude-code-config">{
  "mcpServers": {
    "sitepilotai-<?php echo esc_html( $site_slug ); ?>": {
      "url": "<?php echo esc_url( $mcp_url ); ?>",
      "headers": {
        "X-API-Key": "<?php echo $is_hidden ? 'YOUR_API_KEY_HERE' : esc_attr( $display_key ); ?>"
      }
    }
  }
}</pre>
							<button type="button" class="button spai-copy-code-btn" data-target="spai-claude-code-config">
								<span class="dashicons dashicons-clipboard"></span>
								<?php esc_html_e( 'Copy', 'site-pilot-ai' ); ?>
							</button>
						</div>
					</div>
				</div>

				<div class="spai-step">
					<span class="spai-step-number">2</span>
					<div class="spai-step-content">
						<h3><?php esc_html_e( 'Or use the npm package', 'site-pilot-ai' ); ?></h3>
						<p><?php esc_html_e( 'The site-pilot-ai npm package provides a stdio proxy if your setup requires it:', 'site-pilot-ai' ); ?></p>
						<div class="spai-code-wrapper">
							<pre class="spai-code-block" id="spai-npm-config">{
  "mcpServers": {
    "sitepilotai-<?php echo esc_html( $site_slug ); ?>": {
      "command": "npx",
      "args": ["-y", "site-pilot-ai"],
      "env": {
        "WP_URL": "<?php echo esc_url( home_url() ); ?>",
        "WP_API_KEY": "<?php echo $is_hidden ? 'YOUR_API_KEY_HERE' : esc_attr( $display_key ); ?>",
        "WP_SITE_NAME": "<?php echo esc_attr( $site_slug ); ?>"
      }
    }
  }
}</pre>
							<button type="button" class="button spai-copy-code-btn" data-target="spai-npm-config">
								<span class="dashicons dashicons-clipboard"></span>
								<?php esc_html_e( 'Copy', 'site-pilot-ai' ); ?>
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- ChatGPT -->
		<div class="spai-card">
			<h2>
				<span class="dashicons dashicons-format-chat"></span>
				<?php esc_html_e( 'ChatGPT', 'site-pilot-ai' ); ?>
			</h2>
			<p class="description">
				<?php esc_html_e( 'Use ChatGPT to manage your site via a custom GPT with Actions:', 'site-pilot-ai' ); ?>
			</p>

			<div class="spai-setup-steps">
				<div class="spai-step">
					<span class="spai-step-number">1</span>
					<div class="spai-step-content">
						<h3><?php esc_html_e( 'Create a custom GPT', 'site-pilot-ai' ); ?></h3>
						<p><?php esc_html_e( 'Go to ChatGPT → Explore GPTs → Create and add an Action.', 'site-pilot-ai' ); ?></p>
					</div>
				</div>

				<div class="spai-step">
					<span class="spai-step-number">2</span>
					<div class="spai-step-content">
						<h3><?php esc_html_e( 'Configure authentication', 'site-pilot-ai' ); ?></h3>
						<p><?php esc_html_e( 'Set Authentication to "API Key", Header Name to "X-API-Key", and paste your API key.', 'site-pilot-ai' ); ?></p>
					</div>
				</div>

				<div class="spai-step">
					<span class="spai-step-number">3</span>
					<div class="spai-step-content">
						<h3><?php esc_html_e( 'Import the OpenAPI spec', 'site-pilot-ai' ); ?></h3>
						<p><?php esc_html_e( 'Use the API base URL as your server URL in the OpenAPI schema:', 'site-pilot-ai' ); ?></p>
						<div class="spai-code-wrapper">
							<pre class="spai-code-block" id="spai-rest-url"><?php echo esc_url( $rest_base ); ?></pre>
							<button type="button" class="button spai-copy-code-btn" data-target="spai-rest-url">
								<span class="dashicons dashicons-clipboard"></span>
								<?php esc_html_e( 'Copy', 'site-pilot-ai' ); ?>
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- MCP Endpoint Info -->
		<div class="spai-card">
			<h2>
				<span class="dashicons dashicons-rest-api"></span>
				<?php esc_html_e( 'MCP Endpoint', 'site-pilot-ai' ); ?>
			</h2>
			<p class="description">
				<?php esc_html_e( 'Your site exposes a native MCP (Model Context Protocol) endpoint. Any MCP-compatible AI client can connect:', 'site-pilot-ai' ); ?>
			</p>
			<div class="spai-code-wrapper">
				<pre class="spai-code-block" id="spai-mcp-url"><?php echo esc_url( $mcp_url ); ?></pre>
				<button type="button" class="button spai-copy-code-btn" data-target="spai-mcp-url">
					<span class="dashicons dashicons-clipboard"></span>
					<?php esc_html_e( 'Copy', 'site-pilot-ai' ); ?>
				</button>
			</div>
			<table class="spai-mcp-info-table" style="margin-top:15px;">
				<tr>
					<td><strong><?php esc_html_e( 'Protocol', 'site-pilot-ai' ); ?></strong></td>
					<td><?php esc_html_e( 'JSON-RPC 2.0 over Streamable HTTP (POST + GET)', 'site-pilot-ai' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Auth methods', 'site-pilot-ai' ); ?></strong></td>
					<td><code>X-API-Key</code> <?php esc_html_e( 'header', 'site-pilot-ai' ); ?> · <code>Authorization: Bearer</code> <?php esc_html_e( 'header', 'site-pilot-ai' ); ?> · <code>?api_key=</code> <?php esc_html_e( 'query param', 'site-pilot-ai' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Methods', 'site-pilot-ai' ); ?></strong></td>
					<td><code>initialize</code>, <code>tools/list</code>, <code>tools/call</code>, <code>resources/list</code>, <code>resources/read</code></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Server name', 'site-pilot-ai' ); ?></strong></td>
					<td><code>site-pilot-ai:<?php echo esc_html( $site_name ); ?></code></td>
				</tr>
			</table>
		</div>
	</div>

	<!-- ======================== SETTINGS TAB ======================== -->
	<?php elseif ( 'settings' === $current_tab ) : ?>

	<div class="spai-tab-content">
		<div class="spai-card">
			<h2>
				<span class="dashicons dashicons-awards"></span>
				<?php esc_html_e( 'About', 'site-pilot-ai' ); ?>
			</h2>
			<p class="description">
				<?php esc_html_e( 'All features are included for free. Mumega Site Pilot AI connects your WordPress site to AI assistants via the Model Context Protocol (MCP).', 'site-pilot-ai' ); ?>
			</p>
			<p style="margin-top: 10px;">
				<a href="https://mumega.com/" target="_blank" class="button">
					<span class="dashicons dashicons-external" style="margin-top: 4px;"></span>
					<?php esc_html_e( 'Visit Mumega', 'site-pilot-ai' ); ?>
				</a>
			</p>
		</div>

		<div class="spai-card">
			<h2><?php esc_html_e( 'General Settings', 'site-pilot-ai' ); ?></h2>
			<form method="post" action="options.php">
				<?php
				settings_fields( 'spai_settings_group' );
				do_settings_sections( 'spai_settings' );
				submit_button();
				?>
			</form>
		</div>

		<div class="spai-card">
			<h2><?php esc_html_e( 'Rate Limiting', 'site-pilot-ai' ); ?></h2>
			<form method="post" action="options.php">
				<?php
				settings_fields( 'spai_rate_limit_group' );
				do_settings_sections( 'spai_rate_limit_settings' );
				submit_button( __( 'Save Rate Limits', 'site-pilot-ai' ) );
				?>
			</form>
		</div>

		<div class="spai-card">
			<h2><?php esc_html_e( 'AI Site Context', 'site-pilot-ai' ); ?></h2>
			<form method="post" action="options.php">
				<?php
				settings_fields( 'spai_site_context_group' );
				do_settings_sections( 'spai_site_context_settings' );
				submit_button( __( 'Save Site Context', 'site-pilot-ai' ) );
				?>
			</form>
		</div>

		<?php
		/**
		 * Action for Pro add-on to render additional settings tabs.
		 */
		do_action( 'spai_admin_settings_cards' );
		?>
	</div>

	<!-- ======================== ADVANCED TAB ======================== -->
	<?php elseif ( 'advanced' === $current_tab ) : ?>

	<div class="spai-tab-content">
		<div class="spai-card">
			<h2><?php esc_html_e( 'REST API Reference', 'site-pilot-ai' ); ?></h2>

			<h3><?php esc_html_e( 'API Base URL', 'site-pilot-ai' ); ?></h3>
			<div class="spai-code-wrapper">
				<pre class="spai-code-block" id="spai-base-url"><?php echo esc_url( $rest_base ); ?></pre>
				<button type="button" class="button spai-copy-code-btn" data-target="spai-base-url">
					<span class="dashicons dashicons-clipboard"></span>
					<?php esc_html_e( 'Copy', 'site-pilot-ai' ); ?>
				</button>
			</div>

			<h3><?php esc_html_e( 'Test with curl', 'site-pilot-ai' ); ?></h3>
			<div class="spai-code-wrapper">
				<pre class="spai-code-block" id="spai-curl-test">curl -H "X-API-Key: <?php echo $is_hidden ? 'YOUR_API_KEY' : esc_attr( $display_key ); ?>" \
  "<?php echo esc_url( rest_url( 'site-pilot-ai/v1/site-info' ) ); ?>"</pre>
				<button type="button" class="button spai-copy-code-btn" data-target="spai-curl-test">
					<span class="dashicons dashicons-clipboard"></span>
					<?php esc_html_e( 'Copy', 'site-pilot-ai' ); ?>
				</button>
			</div>

			<h3><?php esc_html_e( 'Test MCP with curl', 'site-pilot-ai' ); ?></h3>
			<div class="spai-code-wrapper">
				<pre class="spai-code-block" id="spai-curl-mcp">curl -X POST "<?php echo esc_url( $mcp_url ); ?>" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: <?php echo $is_hidden ? 'YOUR_API_KEY' : esc_attr( $display_key ); ?>" \
  -d '{"jsonrpc":"2.0","method":"tools/list","id":1}'</pre>
				<button type="button" class="button spai-copy-code-btn" data-target="spai-curl-mcp">
					<span class="dashicons dashicons-clipboard"></span>
					<?php esc_html_e( 'Copy', 'site-pilot-ai' ); ?>
				</button>
			</div>
		</div>

		<div class="spai-card">
			<h2><?php esc_html_e( 'Available Endpoints', 'site-pilot-ai' ); ?></h2>
			<table class="widefat spai-endpoints-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Method', 'site-pilot-ai' ); ?></th>
						<th><?php esc_html_e( 'Endpoint', 'site-pilot-ai' ); ?></th>
						<th><?php esc_html_e( 'Description', 'site-pilot-ai' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr class="spai-endpoint-section"><td colspan="3"><strong><?php esc_html_e( 'Core', 'site-pilot-ai' ); ?></strong></td></tr>
					<tr><td>GET</td><td>/site-info</td><td><?php esc_html_e( 'Site information', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET</td><td>/analytics</td><td><?php esc_html_e( 'API analytics', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET</td><td>/plugins</td><td><?php esc_html_e( 'Detected plugins', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET/POST</td><td>/mcp</td><td><?php esc_html_e( 'MCP protocol endpoint (GET = server info, POST = JSON-RPC)', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>POST</td><td>/oauth/token</td><td><?php esc_html_e( 'OAuth client credentials token endpoint', 'site-pilot-ai' ); ?></td></tr>

					<tr class="spai-endpoint-section"><td colspan="3"><strong><?php esc_html_e( 'Content', 'site-pilot-ai' ); ?></strong></td></tr>
					<tr><td>GET/POST</td><td>/posts</td><td><?php esc_html_e( 'List/create posts', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET/PUT/DELETE</td><td>/posts/{id}</td><td><?php esc_html_e( 'Single post operations', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET/POST</td><td>/pages</td><td><?php esc_html_e( 'List/create pages', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET/PUT</td><td>/pages/{id}</td><td><?php esc_html_e( 'Single page operations', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET/POST</td><td>/media</td><td><?php esc_html_e( 'List/upload media', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>DELETE</td><td>/media/{id}</td><td><?php esc_html_e( 'Delete media attachment', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>POST</td><td>/media/from-url</td><td><?php esc_html_e( 'Upload from URL', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET</td><td>/drafts</td><td><?php esc_html_e( 'List drafts', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>DELETE</td><td>/drafts/delete-all</td><td><?php esc_html_e( 'Delete all drafts', 'site-pilot-ai' ); ?></td></tr>

					<tr class="spai-endpoint-section"><td colspan="3"><strong><?php esc_html_e( 'Elementor', 'site-pilot-ai' ); ?></strong></td></tr>
					<tr><td>GET</td><td>/elementor/status</td><td><?php esc_html_e( 'Elementor status', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET/POST</td><td>/elementor/{id}</td><td><?php esc_html_e( 'Get/set Elementor data', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET</td><td>/elementor/{id}/summary</td><td><?php esc_html_e( 'Lightweight structural summary', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>POST</td><td>/elementor/{id}/edit-section</td><td><?php esc_html_e( 'Surgical element editing', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>POST</td><td>/elementor/page</td><td><?php esc_html_e( 'Create Elementor page', 'site-pilot-ai' ); ?></td></tr>

					<?php if ( $is_pro ) : ?>
					<tr class="spai-endpoint-section"><td colspan="3"><strong><?php esc_html_e( 'Pro: SEO', 'site-pilot-ai' ); ?> <span class="spai-badge spai-badge-pro">PRO</span></strong></td></tr>
					<tr><td>GET/POST</td><td>/seo/{id}</td><td><?php esc_html_e( 'Get/set SEO metadata', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET</td><td>/seo/{id}/analyze</td><td><?php esc_html_e( 'SEO analysis', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET</td><td>/seo/status</td><td><?php esc_html_e( 'SEO plugin status', 'site-pilot-ai' ); ?></td></tr>

					<tr class="spai-endpoint-section"><td colspan="3"><strong><?php esc_html_e( 'Pro: Forms', 'site-pilot-ai' ); ?> <span class="spai-badge spai-badge-pro">PRO</span></strong></td></tr>
					<tr><td>GET</td><td>/forms</td><td><?php esc_html_e( 'List forms', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET</td><td>/forms/{plugin}/{id}</td><td><?php esc_html_e( 'Get form details', 'site-pilot-ai' ); ?></td></tr>
					<tr><td>GET</td><td>/forms/status</td><td><?php esc_html_e( 'Forms plugin status', 'site-pilot-ai' ); ?></td></tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

		<?php
		/**
		 * Action for Pro add-on to render additional admin tab content.
		 */
		do_action( 'spai_admin_tab_content', 'advanced' );
		?>

		<div class="spai-card">
			<h2><?php esc_html_e( 'Resources', 'site-pilot-ai' ); ?></h2>
			<ul class="spai-resources-list">
				<li>
					<span class="dashicons dashicons-book"></span>
					<a href="https://sitepilotai.mumega.com/docs" target="_blank"><?php esc_html_e( 'Documentation & Source Code', 'site-pilot-ai' ); ?></a>
				</li>
				<li>
					<span class="dashicons dashicons-sos"></span>
					<a href="https://github.com/Digidinc/wp-ai-operator/issues" target="_blank"><?php esc_html_e( 'Report a Bug', 'site-pilot-ai' ); ?></a>
				</li>
				<li>
					<span class="dashicons dashicons-info"></span>
					<a href="https://modelcontextprotocol.io" target="_blank"><?php esc_html_e( 'About MCP (Model Context Protocol)', 'site-pilot-ai' ); ?></a>
				</li>
			</ul>
		</div>
	</div>

	<!-- ======================== CHANGELOG TAB ======================== -->
	<?php elseif ( 'changelog' === $current_tab ) : ?>

	<div class="spai-tab-content">
		<div class="spai-card">
			<h2>
				<span class="dashicons dashicons-list-view"></span>
				<?php esc_html_e( 'Changelog', 'site-pilot-ai' ); ?>
				<span class="spai-version" style="margin-left:8px;">
					<?php
					/* translators: %s: current plugin version */
					printf( esc_html__( 'Current: v%s', 'site-pilot-ai' ), esc_html( SPAI_VERSION ) );
					?>
				</span>
			</h2>

			<div class="spai-changelog">
				<?php
				$readme_path = SPAI_PLUGIN_DIR . 'readme.txt';
				$changelog_html = '';

				if ( file_exists( $readme_path ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local file
					$readme_content = file_get_contents( $readme_path );
					$changelog_pos  = strpos( $readme_content, '== Changelog ==' );

					if ( false !== $changelog_pos ) {
						$changelog_text = substr( $readme_content, $changelog_pos + strlen( '== Changelog ==' ) );
						// Stop at the next == section
						$next_section = strpos( $changelog_text, "\n== " );
						if ( false !== $next_section ) {
							$changelog_text = substr( $changelog_text, 0, $next_section );
						}

						// Parse the changelog into version blocks
						$lines   = explode( "\n", trim( $changelog_text ) );
						$version = '';
						$items   = array();
						$first   = true;

						foreach ( $lines as $line ) {
							$line = trim( $line );
							if ( empty( $line ) ) {
								continue;
							}

							// Version header: = X.Y.Z =
							if ( preg_match( '/^= (.+?) =$/', $line, $m ) ) {
								// Output previous version block
								if ( $version && ! empty( $items ) ) {
									$is_current = version_compare( trim( $version, ' ' ), SPAI_VERSION, '==' );
									$open_attr  = $first ? ' open' : '';
									echo '<details class="spai-changelog-version"' . $open_attr . '>';
									echo '<summary>';
									echo '<strong>' . esc_html( 'v' . $version ) . '</strong>';
									if ( $is_current ) {
										echo ' <span class="spai-badge" style="background:#28a745;color:#fff;">' . esc_html__( 'Current', 'site-pilot-ai' ) . '</span>';
									}
									echo '</summary>';
									echo '<ul class="spai-changelog-items">';
									foreach ( $items as $item ) {
										echo '<li>' . esc_html( $item ) . '</li>';
									}
									echo '</ul>';
									echo '</details>';
									$first = false;
								}
								$version = $m[1];
								$items   = array();
							} elseif ( preg_match( '/^\* (.+)$/', $line, $m ) ) {
								$items[] = $m[1];
							}
						}

						// Output last version block
						if ( $version && ! empty( $items ) ) {
							$is_current = version_compare( trim( $version, ' ' ), SPAI_VERSION, '==' );
							echo '<details class="spai-changelog-version">';
							echo '<summary>';
							echo '<strong>' . esc_html( 'v' . $version ) . '</strong>';
							if ( $is_current ) {
								echo ' <span class="spai-badge" style="background:#28a745;color:#fff;">' . esc_html__( 'Current', 'site-pilot-ai' ) . '</span>';
							}
							echo '</summary>';
							echo '<ul class="spai-changelog-items">';
							foreach ( $items as $item ) {
								echo '<li>' . esc_html( $item ) . '</li>';
							}
							echo '</ul>';
							echo '</details>';
						}
					}
				}

				if ( empty( $changelog_text ) ) {
					echo '<p><em>' . esc_html__( 'Changelog not available.', 'site-pilot-ai' ) . '</em></p>';
				}
				?>
			</div>
		</div>
	</div>

	<?php endif; ?>

</div>
